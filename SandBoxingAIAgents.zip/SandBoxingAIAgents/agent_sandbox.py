"""
agent_sandbox.py

A minimal AI agent sandbox implemented in plain Python.

It enforces four boundaries around anything an agent tries to do:
  1. Filesystem  — the agent can only read/write inside a designated jail directory
  2. Process     — the agent can only spawn commands from an explicit allowlist
  3. Resources   — CPU time, memory, and wall-clock time are all capped
  4. Audit       — every attempted action is logged, allowed or not

IMPORTANT LIMITATIONS (read before relying on this in production):
  - This is a *process-level* sandbox using POSIX resource limits (Linux/macOS only;
    `resource` module has no Windows support). It does NOT provide kernel-level
    isolation like a container, VM, or gVisor/Firecracker.
  - Network isolation here is enforced only for code that goes through
    `SandboxedExecutor.run_python`, by disabling the `socket` module inside the
    child process. A determined agent with raw subprocess access could bypass this.
  - For real production use with untrusted or high-autonomy agents, put this INSIDE
    a container (Docker with --network=none, --memory, --pids-limit, --read-only)
    or a proper microVM sandbox (Firecracker, gVisor). Treat this module as the
    inner policy layer, not the full security boundary.
"""

from __future__ import annotations

import os
import resource
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional


class SandboxViolation(Exception):
    """Raised when the agent attempts an action outside its granted policy."""


@dataclass
class SandboxPolicy:
    """Declarative policy for what a sandboxed agent session is allowed to do."""

    allowed_commands: set[str] = field(default_factory=set)   # e.g. {"python3", "git"}
    max_cpu_seconds: int = 5                                  # CPU time cap per subprocess
    max_memory_mb: int = 256                                  # address space cap
    max_wall_seconds: int = 10                                # wall-clock timeout
    max_output_bytes: int = 1_000_000                         # cap stdout/stderr captured
    allow_network: bool = False                                # only affects run_python()
    env_allowlist: set[str] = field(default_factory=lambda: {"PATH", "LANG"})


class FileJail:
    """
    Restricts filesystem access to a single root directory.

    Every path the agent wants to touch is resolved and checked against the jail
    root. Symlink or '..' traversal outside the root raises SandboxViolation.
    """

    def __init__(self, root: Optional[Path] = None):
        self.root = (root or Path(tempfile.mkdtemp(prefix="agent_sandbox_"))).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def resolve(self, relative_path: str) -> Path:
        candidate = (self.root / relative_path).resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError:
            raise SandboxViolation(
                f"Path '{relative_path}' escapes sandbox root {self.root}"
            )
        return candidate

    def read(self, relative_path: str) -> bytes:
        return self.resolve(relative_path).read_bytes()

    def write(self, relative_path: str, data: bytes) -> None:
        path = self.resolve(relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)

    def cleanup(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)


class AuditLog:
    """Append-only in-memory record of every action attempted, allowed or denied."""

    def __init__(self):
        self.entries: list[dict] = []

    def record(self, action: str, allowed: bool, detail: str = "") -> None:
        self.entries.append(
            {
                "id": str(uuid.uuid4()),
                "ts": time.time(),
                "action": action,
                "allowed": allowed,
                "detail": detail,
            }
        )

    def denied(self) -> list[dict]:
        return [e for e in self.entries if not e["allowed"]]


def _limit_resources(policy: SandboxPolicy) -> Callable[[], None]:
    """
    Returns a function suitable for subprocess `preexec_fn` that applies
    CPU and memory limits to the child process before it execs.
    Linux/macOS only.
    """

    def _apply():
        resource.setrlimit(
            resource.RLIMIT_CPU, (policy.max_cpu_seconds, policy.max_cpu_seconds)
        )
        mem_bytes = policy.max_memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        # Prevent forking a swarm of child processes
        resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))

    return _apply


class SandboxedExecutor:
    """
    The enforcement point. All agent actions go through here, so this is
    the single place a governance layer (policy source, audit sink) plugs in.
    """

    def __init__(self, policy: SandboxPolicy, jail: Optional[FileJail] = None):
        self.policy = policy
        self.jail = jail or FileJail()
        self.audit = AuditLog()

    def run_command(self, command: list[str]) -> subprocess.CompletedProcess:
        """Run an external command, enforcing the command allowlist and all resource caps."""
        binary = command[0]
        if binary not in self.policy.allowed_commands:
            self.audit.record("run_command", allowed=False, detail=binary)
            raise SandboxViolation(f"Command '{binary}' is not in the allowlist")

        env = {k: os.environ[k] for k in self.policy.env_allowlist if k in os.environ}

        self.audit.record("run_command", allowed=True, detail=" ".join(command))
        try:
            result = subprocess.run(
                command,
                cwd=self.jail.root,
                env=env,
                preexec_fn=_limit_resources(self.policy) if os.name == "posix" else None,
                timeout=self.policy.max_wall_seconds,
                capture_output=True,
                text=True,
            )
        except subprocess.TimeoutExpired as e:
            self.audit.record("run_command_timeout", allowed=False, detail=str(e))
            raise SandboxViolation(f"Command exceeded {self.policy.max_wall_seconds}s wall clock")

        result.stdout = result.stdout[: self.policy.max_output_bytes]
        result.stderr = result.stderr[: self.policy.max_output_bytes]
        return result

    def run_python(self, code: str) -> subprocess.CompletedProcess:
        """
        Run a snippet of Python code in a fresh, resource-limited subprocess.
        Network access inside the snippet is disabled unless policy.allow_network is True.
        """
        if "python3" not in self.policy.allowed_commands:
            raise SandboxViolation("python3 is not in the allowlist for this policy")

        guard = ""
        if not self.policy.allow_network:
            guard = (
                "import socket\n"
                "def _blocked(*a, **k): raise RuntimeError('network disabled in sandbox')\n"
                "socket.socket = _blocked\n"
            )

        script_path = self.jail.resolve(f"_agent_{uuid.uuid4().hex}.py")
        script_path.write_text(guard + code)

        try:
            return self.run_command(["python3", str(script_path)])
        finally:
            script_path.unlink(missing_ok=True)

    def read_file(self, relative_path: str) -> bytes:
        self.audit.record("read_file", allowed=True, detail=relative_path)
        return self.jail.read(relative_path)

    def write_file(self, relative_path: str, data: bytes) -> None:
        self.audit.record("write_file", allowed=True, detail=relative_path)
        self.jail.write(relative_path, data)

    def shutdown(self) -> None:
        self.jail.cleanup()


# ---------------------------------------------------------------------------
# Example usage
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    policy = SandboxPolicy(
        allowed_commands={"python3"},
        max_cpu_seconds=2,
        max_memory_mb=128,
        max_wall_seconds=5,
        allow_network=False,
    )

    sandbox = SandboxedExecutor(policy)

    # Allowed: writing inside the jail, then running an allowlisted command
    sandbox.write_file("hello.txt", b"agent was here")
    result = sandbox.run_python("print('sandboxed agent says hi')")
    print("stdout:", result.stdout.strip())

    # Denied: command not on the allowlist
    try:
        sandbox.run_command(["rm", "-rf", "/"])
    except SandboxViolation as e:
        print("blocked as expected:", e)

    # Denied: path traversal outside the jail
    try:
        sandbox.read_file("../../../etc/passwd")
    except SandboxViolation as e:
        print("blocked as expected:", e)

    print("\naudit trail:")
    for entry in sandbox.audit.entries:
        print(f"  [{'OK' if entry['allowed'] else 'DENIED'}] {entry['action']}: {entry['detail']}")

    sandbox.shutdown()
