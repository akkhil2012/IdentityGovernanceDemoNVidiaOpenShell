What it enforces:

Boundary	Mechanism
Filesystem	FileJail resolves every path against a root directory and rejects anything that escapes it (blocks ../../etc/passwd-style traversal)
Process	SandboxedExecutor only runs commands on an explicit allowlist
CPU / memory	resource.setrlimit caps CPU seconds, address space, and process count before the child execs
Wall clock	subprocess.run(timeout=...) kills anything that runs too long
Network	Optional — run_python monkey-patches socket.socket inside the child so snippets can't open connections unless explicitly allowed
Audit	Every action, allowed or denied, lands in AuditLog — this is the piece that maps to what OpenShell's Gateway does at a bigger scale

Be honest about the ceiling here: this is a process-level sandbox using POSIX rlimits — real defense-in-depth for a script or tool call, but not kernel-level isolation. It won't stop a sufficiently privileged subprocess from doing things resource limits don't cover. For anything running untrusted or high-autonomy agent code in production, wrap this policy layer inside an actual container (docker run --network=none --memory=256m --pids-limit=32 --read-only) or a microVM (Firecracker, gVisor) — that's the real boundary; this module is the inner policy enforcement on top of it, which is roughly the same layering OpenShell itself uses (Gateway policy layer on top of kernel-level sandboxing).
